export default {
    products: [],
    cart:  [],
    userData: {}
}