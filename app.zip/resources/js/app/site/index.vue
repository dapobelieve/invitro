<template>
    <div class="siteapp">
        <router-view></router-view>
    </div>
</template>