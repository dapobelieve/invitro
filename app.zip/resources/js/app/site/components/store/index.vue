<template>
    <div class="store">
        <transition name="fadeLeft">
            <router-view></router-view>
        </transition>
    </div>
</template>