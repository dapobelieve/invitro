import adminRoutes from './admin/routes';

import siteRoutes from './site/routes'


export default [...adminRoutes, ...siteRoutes];