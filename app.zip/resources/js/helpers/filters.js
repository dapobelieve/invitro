

const filters = {
    toNaira: ('toNaira', (value) => {
        return '&#x20A6'+ value
    })
}


export default filters