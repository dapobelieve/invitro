<div id="user-nav">
    <ul class="btn-group">
        <li class="btn" ><a title="" href="#"><i class="fa fa-user"></i> <span class="text">Profile</span></a></li>
        <li class="btn dropdown" id="menu-messages"><a href="#" data-toggle="dropdown" data-target="#menu-messages" class="dropdown-toggle"><i class="fa fa-envelope"></i> <span class="text">Messages</span> <span class="label label-danger">5</span> <b class="caret"></b></a>
            <ul class="dropdown-menu messages-menu">
                <li class="title"><i class="fa fa-envelope-alt"></i>Messages<a class="title-btn" href="#" title="Write new message"><i class="fa fa-share"></i></a></li>
                <li class="message-item">
                    <a href="#">
                        <img alt="User Icon" src="img/demo/av1.jpg" />
                        <div class="message-content">
                            <span class="message-time">
                                3 mins ago
                            </span>
                            <span class="message-sender">
                                Nunc Cenenatis
                            </span>
                            <span class="message">
                                Hi, can you meet me at the office tomorrow morning?
                            </span>
                        </div>
                    </a>
                </li>
                <li class="message-item">
                    <a href="#">
                        <img alt="User Icon" src="img/demo/av1.jpg" />
                        <div class="message-content">
                            <span class="message-time">
                                3 mins ago
                            </span>
                            <span class="message-sender">
                                Nunc Cenenatis
                            </span>
                            <span class="message">
                                Hi, can you meet me at the office tomorrow morning?
                            </span>
                        </div>
                    </a>
                </li>
                <li class="message-item">
                    <a href="#">
                        <img alt="User Icon" src="img/demo/av1.jpg" />
                        <div class="message-content">
                            <span class="message-time">
                                3 mins ago
                            </span>
                            <span class="message-sender">
                                Nunc Cenenatis
                            </span>
                            <span class="message">
                                Hi, can you meet me at the office tomorrow morning?
                            </span>
                        </div>
                    </a>
                </li>
            </ul>
        </li>
        <li class="btn"><a title="" href="#"><i class="fa fa-cog"></i> <span class="text">Settings</span></a></li>
        <li class="btn"><a title="" href="login.html"><i class="fa fa-share"></i> <span class="text">Logout</span></a></li>
    </ul>
</div>