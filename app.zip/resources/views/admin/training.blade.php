@extends('admin.layout.template')
@section('admin-title', 'IVF Dashboard | Trainings')

@section('admin-content')


    <div id="content">
        <div id="content-header" class="mini">
            <h1>Trainings</h1>
        </div>
        <adminer></adminer>
    </div>
@stop