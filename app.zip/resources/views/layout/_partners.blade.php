<section class="cs gradient section_padding_top_50 section_padding_bottom_50">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="owl-carousel partners-carousel" data-responsive-lg="9" data-responsive-md="6" data-responsive-sm="4" data-responsive-xs="2" data-nav="false" data-dots="false" data-center="true" data-loop="true"> <a href="#">
                        <img src="/assets/images/partners/01.png" alt="">
                    </a> <a href="#">
                        <img src="/assets/images/partners/02.png" alt="">
                    </a> <a href="#">
                        <img src="/assets/images/partners/03.png" alt="">
                    </a> <a href="#">
                        <img src="/assets/images/partners/04.png" alt="">
                    </a> <a href="#">
                        <img src="/assets/images/partners/05.png" alt="">
                    </a> <a href="#">
                        <img src="/assets/images/partners/06.png" alt="">
                    </a> <a href="#">
                        <img src="/assets/images/partners/07.png" alt="">
                    </a> <a href="#">
                        <img src="/assets/images/partners/08.png" alt="">
                    </a> <a href="#">
                        <img src="/assets/images/partners/09.png" alt="">
                    </a> </div>
                        </div>
                    </div>
                </div>
            </section>