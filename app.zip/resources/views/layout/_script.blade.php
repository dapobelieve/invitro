<script src="/assets/js/compressed.js"></script>
<script src="/assets/js/main.js"></script>
<script src="js/app.js"></script>