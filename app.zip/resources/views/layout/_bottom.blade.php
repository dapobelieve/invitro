<section class="ds color darker page_copyright section_padding_15">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <p class="fontsize_12">&copy; Copyright {{ date('Y')  }}. All Rights Reserved. </p>
                <p>
                    <small>Built by
                        <a title="{{ config('site.site.developer.phone') }}" href="{{ config('site.site.developer.site') }}">{{ config('site.site.developer.name') }}</a>
                    </small>
                </p>
            </div>
        </div>
    </div>
</section>