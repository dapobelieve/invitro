<section class="cs gradient section_padding_top_65 section_padding_bottom_50 columns_margin_bottom_20">
                <div class="container">
                    <div class="row">
                        <div class="col-md-20 col-sm-4 col-xs-6 col-xxs-12">
                            <div class="teaser text-center">
                                <h3 class="counter" data-from="0" data-to="25" data-speed="2100">0</h3>
                                <p>Years Experience</p>
                            </div>
                        </div>
                        <div class="col-md-20 col-sm-4 col-xs-6 col-xxs-12">
                            <div class="teaser text-center">
                                <h3 class="counter" data-from="0" data-to="893" data-speed="2100">0</h3>
                                <p>Happy Families</p>
                            </div>
                        </div>
                        <div class="col-md-20 col-sm-4 col-xs-6 col-xxs-12">
                            <div class="teaser text-center">
                                <h3 class="counter" data-from="0" data-to="75" data-speed="2100">0</h3>
                                <p>Trained Students</p>
                            </div>
                        </div>
                        <div class="col-md-20 col-sm-6 col-xs-6 col-xxs-12">
                            <div class="teaser text-center">
                                <h3 class="counter-wrap">
                                    <span class="counter" data-from="0" data-to="1063" data-speed="2100"></span>
                                    <span class="counter-add"></span> </h3>
                                <p>Products Sold</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>