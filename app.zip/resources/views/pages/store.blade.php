@extends('pages.template')

@section('page.title', 'Our Products | '. config('site.site.name'))

@section('content')

    <siter></siter>

@stop