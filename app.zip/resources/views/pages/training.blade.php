@extends('pages.template')

@section('page.title', 'Trainings | '. config('site.site.name'))

@section('content')
    <siter></siter>
@stop