<div id="sidebar">
    <ul>
        <li class="<?php echo e(Request::is('dashboard/home')  ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin')); ?>">
            <i class="fa fa-home"></i> <span>Dashboard</span></a>
        </li>
        <li class="<?php echo e(Request::is('dashboard/training')  ? 'active' : ''); ?>">
            <a href="<?php echo e(url('dashboard/training#/home')); ?>">
                <i class="fa fa-medkit"></i>
                <span>Trainings</span>
            </a>
        </li>
        <li class="<?php echo e(Request::is('dashboard/store')  ? 'active' : ''); ?>">
            <a href="<?php echo e(url('dashboard/store#/store')); ?>">
                <i class="fa fa-shopping-cart"></i>
                <span>Store</span>
            </a>
        </li>
    </ul>
</div>