<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('admin.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>   

    <body data-color="grey" class="flat ">
        <div id="wrapper">
            <div id="header">
                <a id="menu-trigger" href="#"><i class="fa fa-bars"></i></a>
            </div>
        
            
           
            <?php echo $__env->make('admin.layout._adminNav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div id="app">
                <?php echo $__env->yieldContent('admin-content'); ?>
            </div>

            <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

            <?php echo $__env->make('admin.layout.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <script>
            menuTrigger = document.getElementById('menu-trigger');
            menuTrigger.addEventListener('click', function () {
                document.body.classList.toggle('menu-open');
            })
        </script>
    </body>


</html>
