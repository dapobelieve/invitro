<!DOCTYPE html>
<html class="no-js">
<!--<![endif]-->
<?php echo $__env->make('layout._head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>
    <div class="preloader">
        <div class="preloader_image"></div>
    </div>
    <!-- eof .modal -->
    <!-- wrappers for visual page editor and boxed version of template -->
    <div id="canvas">
        <div id="box_wrapper">
            <!-- template sections -->
            <?php echo $__env->make('layout._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('layout._nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <section class="ls section_404 background_cover section_padding_top_130 section_padding_bottom_100">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 text-center text-md-right">
                            <div class="inline-block text-center">
                                <p class="not_found"> <span class="highlight2">404</span> <span class="oops grey">Ooops!</span> </p>
                                <h3 class="text-uppercase">Sorry page nor found!</h3>
                                <p> <a href="<?php echo e(route('home')); ?>" class="theme_button color2 min_width_button">Back to Home</a> </p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <?php echo $__env->make('layout._bottom', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <!-- eof #box_wrapper -->
    </div>
    <!-- eof #canvas -->
    <?php echo $__env->make('layout._script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>