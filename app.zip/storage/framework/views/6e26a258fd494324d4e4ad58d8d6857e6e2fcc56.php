<div id="sidebar">
    <ul>
        <li class="active"><a href="#">
            <i class="fa fa-home"></i> <span>Dashboard</span></a>
        </li>
        <li class="">
            <a href="#">
                <span>Trainings</span>
            </a>
        </li>
        <li class="">
            <a href="#">
                <span>Store</span>
            </a>
        </li>
    </ul>
</div>