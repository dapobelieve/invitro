<section id="blog" class="ls  section_padding_bottom_100">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h2 class="section_header text-center">Latest Trainings</h2>
                <div class="row">
                    <div class="col-md-6">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!$loop->first): ?>
                                <div class="panel-group" id="posts-accordion<?php echo e($loop->index); ?>">
                                    <div class="panel panel-blog-post">
                                        <div class="panel-heading">
                                            <a data-toggle="collapse" data-parent="#posts-accordion<?php echo e($loop->index); ?>" href="#blog-collapse<?php echo e($loop->index + 1); ?>"> </a>
                                            <div class="date entry-meta-corner">
                                                <span><?php echo e($course->created_at->day); ?></span>
                                                <span><?php echo e($course->created_at->month); ?>/<?php echo e(substr($course->created_at->year, 2, 3)); ?></span>
                                            </div>
                                            <h4 class="hover-color2">
                                                <a href="<?php echo e(url('trainings#/details/'.$course->slug)); ?>"><?php echo e($course->title); ?></a>
                                            </h4>
                                            <div class="content-justify greylinks fontsize_12">
                                                <a href="#">
                                                    <i class="fa fa-user rightpadding_5" aria-hidden="true"></i> by Admin
                                                </a>
                                                <a href="#">
                                                    <i class="fa fa-comment rightpadding_5" aria-hidden="true"></i>
                                                    <span class="amount">87</span>
                                                </a>
                                            </div>
                                        </div>
                                        <div id="blog-collapse<?php echo e($loop->index + 1); ?>"
                                             class="panel-collapse collapse <?php echo e(($loop->index == 1) ? 'in' : ''); ?> ">
                                            <div class="panel-body">
                                                <?php echo html_entity_decode(str_limit($course->content, 50)); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="col-md-6">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($loop->first): ?>
                                <div class="vertical-item content-absolute content-padding">
                            <div class="item-media rounded overflow_hidden ds black">
                                <img src="/assets/images/blog_post1.jpg" alt="">
                                <div class="date entry-meta-corner main_bg_color">
                                    <span><?php echo e($course->created_at->day); ?></span>
                                    <span><?php echo e($course->created_at->month); ?>/<?php echo e(substr($course->created_at->year, 2, 3)); ?></span>
                                </div>
                            </div>
                            <div class="item-content ds">
                                <h4 class="entry-title highlight hover-color2 bottommargin_0">
                                    <a href="<?php echo e(url('trainings#/details/'.$course->slug)); ?>"><?php echo e($course->title); ?></a>
                                </h4>
                                <div class="content-justify darklinks fontsize_12 regular">
                                    <a href="#">
                                        <i class="fa fa-user rightpadding_5" aria-hidden="true"></i> by Admin
                                    </a>
                                    <a href="#">
                                        <i class="fa fa-comment rightpadding_5" aria-hidden="true"></i>
                                        <span class="amount">75</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>