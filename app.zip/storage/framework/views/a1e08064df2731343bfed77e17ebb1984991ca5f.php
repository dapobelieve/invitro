<?php $__env->startSection('page.title', 'Trainings | '. config('site.site.name')); ?>

<?php $__env->startSection('content'); ?>
    <siter></siter>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>