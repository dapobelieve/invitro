<?php $__env->startSection('admin-title', config('site.site.admin.name').' | Store'); ?>

<?php $__env->startSection('admin-content'); ?>


    <div id="content">
        <div id="content-header" class="mini">
            <h1>Store Management</h1>
        </div>
        <adminer></adminer>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>