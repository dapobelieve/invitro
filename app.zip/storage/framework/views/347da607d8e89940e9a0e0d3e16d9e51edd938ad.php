<header class="page_header header_color toggler_left">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 display_table">
                <div class="header_mainmenu display_table_cell">
                    <!-- main nav start -->
                    <nav class="mainmenu_wrapper">
                        <ul class="mainmenu nav sf-menu">
                            <li class="<?php echo e(Request::is('/') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('home')); ?>">Home</a>
                            </li>
                            <li class="<?php echo e(Request::is('trainings') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('trainings#/trainings')); ?>">Trainings</a>
                            </li>
                            <li class="<?php echo e(Request::is('shop') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('shop#/products')); ?>">Store</a>
                            </li>
                            <li class="<?php echo e(Request::is('about-us') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('about')); ?>">About Us</a>
                            </li>
                            <li class="<?php echo e(Request::is('contact') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('contact')); ?>">Contact Us</a>
                            </li>
                            <!-- eof contacts -->
                        </ul>
                    </nav>
                    <!-- eof main nav -->
                    <!-- header toggler --><span class="toggle_menu"><span></span></span>
                </div>
                <div class="header_right_buttons cs display_table_cell text-right">
                    <ul class="inline-list menu greylinks" style="margin-top: 10px; margin-bottom: 10px;">
                        <li>
                          
                            
                          
                        </li>
                        <li>
                            
                                  
                              
                        </li>
                        <li>
                            
                                
                            
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</header>