<?php $__env->startSection('admin-title', 'IVF Dashboard'); ?>

<?php $__env->startSection('admin-content'); ?>

<div id="content">
    <div id="content-header" class="mini">
        <h1>Dashboard</h1>
    </div>
    <div id="breadcrumb">
        <a href="#" title="Go to Home" class="tip-bottom"><i class="fa fa-home"></i> Home</a>
        <a href="#" class="current">Dashboard</a>
    </div>
    <div class="container-fluid">
        <?php echo $__env->make('admin.layout.stats', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <br />

        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-info">
                    Welcome in the <strong>Unicorn Admin Theme</strong>. Don't forget to check all the pages!
                    <a href="#" data-dismiss="alert" class="close">×</a>
                </div>
                <div class="widget-box">
                    <div class="widget-title">
                        <span class="icon"><i class="fa fa-signal"></i></span>
                        <h5>Site Statistics</h5>
                        <div class="buttons">
                            <a href="#" class="btn"><i class="fa fa-refresh"></i> <span class="text">Update stats</span></a>
                        </div>
                    </div>
                    <div class="widget-content">
                        <div class="row">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>